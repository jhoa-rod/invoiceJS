import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAppContext } from "../context/AppContext";
import { SectionHeader } from "../components/common/SectionHeader";

export function NewTaskPage() {
  const navigate = useNavigate();
  const { state, addTask } = useAppContext();
  const [form, setForm] = useState({
    name: "",
    description: "",
    priority: "high",
    status: "pending",
    dueDate: new Date().toISOString().slice(0, 10),
    estimatedMinutes: 60,
    actualMinutes: 0,
    weeklyTargetMinutes: 120,
    todayMinutes: 30,
    category: "",
    goalId: state.goals[0]?.id || "",
    notes: "",
  });

  function updateField(key, value) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function handleSubmit(event) {
    event.preventDefault();
    const task = addTask({
      ...form,
      progress: form.status === "completed" ? 100 : form.status === "in_progress" ? 50 : 0,
      plannedMinutesByDate: {
        [form.dueDate]: Number(form.todayMinutes || 0),
      },
      phases: {
        monthly: [],
        weekly: [],
        daily: [],
      },
    });
    navigate(`/tasks/${task.id}`);
  }

  return (
    <div className="page-stack">
      <SectionHeader
        eyebrow="New task"
        title="Create a task in its own workspace"
        description="Keep the task setup clean with timing, category, goal, and planning data."
      />

      <form className="panel form-grid" onSubmit={handleSubmit}>
        <label className="field">
          <span>Task name</span>
          <input
            value={form.name}
            onChange={(event) => updateField("name", event.target.value)}
            required
          />
        </label>
        <label className="field field-span-2">
          <span>Note or description</span>
          <textarea
            value={form.description}
            onChange={(event) => updateField("description", event.target.value)}
          />
        </label>
        <label className="field">
          <span>Priority</span>
          <select
            value={form.priority}
            onChange={(event) => updateField("priority", event.target.value)}
          >
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </label>
        <label className="field">
          <span>Status</span>
          <select
            value={form.status}
            onChange={(event) => updateField("status", event.target.value)}
          >
            <option value="pending">Pending</option>
            <option value="in_progress">In progress</option>
            <option value="completed">Completed</option>
          </select>
        </label>
        <label className="field">
          <span>Target date</span>
          <input
            type="date"
            value={form.dueDate}
            onChange={(event) => updateField("dueDate", event.target.value)}
          />
        </label>
        <label className="field">
          <span>Estimated time</span>
          <input
            type="number"
            min="0"
            value={form.estimatedMinutes}
            onChange={(event) => updateField("estimatedMinutes", Number(event.target.value))}
          />
        </label>
        <label className="field">
          <span>Weekly planned time</span>
          <input
            type="number"
            min="0"
            value={form.weeklyTargetMinutes}
            onChange={(event) =>
              updateField("weeklyTargetMinutes", Number(event.target.value))
            }
          />
        </label>
        <label className="field">
          <span>Today's planned time</span>
          <input
            type="number"
            min="0"
            value={form.todayMinutes}
            onChange={(event) => updateField("todayMinutes", Number(event.target.value))}
          />
        </label>
        <label className="field">
          <span>Category</span>
          <input
            value={form.category}
            onChange={(event) => updateField("category", event.target.value)}
          />
        </label>
        <label className="field field-span-2">
          <span>Linked goal</span>
          <select
            value={form.goalId}
            onChange={(event) => updateField("goalId", event.target.value)}
          >
            {state.goals.map((goal) => (
              <option key={goal.id} value={goal.id}>
                {goal.title}
              </option>
            ))}
          </select>
        </label>
        <label className="field field-span-2">
          <span>Execution notes</span>
          <textarea
            value={form.notes}
            onChange={(event) => updateField("notes", event.target.value)}
          />
        </label>
        <button className="action-button field-span-2" type="submit">
          Create task
        </button>
      </form>
    </div>
  );
}
