# Google Login Setup

1. Crea un proyecto en Supabase.
2. Ve a `Authentication`.
3. Abre `Providers`.
4. Activa `Google`.
5. Crea credenciales OAuth en Google Cloud.
6. Copia `Client ID` y `Client Secret` dentro de Supabase.
7. Configura `Site URL` con `http://localhost:5173` para desarrollo.
8. Configura la redirect URL:
   - `http://localhost:5173`
   - En producción usa la URL real de la app.
9. Prueba el inicio de sesión con Google.

Variables necesarias:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
